<?php

namespace App\Ecommerce\Chat\Framework\Controllers;

class ChatController
{
    //
}
