<?php

namespace App\Core\Framework\Controllers;

abstract class Controller
{
    //
}
