<script setup lang="ts">

</script>

<template>
    <div class="flex-grow">
        <figure class="hidden h-full items-center justify-center text-center lg:flex"><img
            class="block max-w-sm dark:hidden" src="https://dashboard.shadcnuikit.com/images/not-selected-chat.svg"
            alt="..."><img class="hidden max-w-sm dark:block"
                           src="https://dashboard.shadcnuikit.com/images/not-selected-chat-light.svg" alt="...">
        </figure>
    </div>
</template>

<style scoped>

</style>
