type MenuItem = {
    name: String,
    href: String,
    logo: String
}


export interface MenuItemProps {
    menus: MenuItem
}
