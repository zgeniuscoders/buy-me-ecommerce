<template>

    <admin-layout>

    </admin-layout>

</template>


<script setup lang="ts">


import adminLayout from '../layouts/adminLayout.vue';
</script>
