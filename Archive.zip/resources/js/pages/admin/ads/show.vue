<script setup lang="ts">
import AdminLayout from "@/pages/admin/layouts/adminLayout.vue";
</script>

<template>
    <admin-layout>

    </admin-layout>
</template>

<style scoped>

</style>
