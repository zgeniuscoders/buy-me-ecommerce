import { ProductType } from "./ProductType";

export interface ProductProps {
    product: ProductType
}