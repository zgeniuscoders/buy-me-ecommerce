export interface ProductOrder{
    productId: number,
    productQty: number
}
