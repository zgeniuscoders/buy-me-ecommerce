export interface Ads{
    id: number,
    product_id: number,
    title: string,
    description: string,
    sub_title: string,
    image: string,
    button_text: string,
    start_at: string,
    end_at: string,
    url: string,
    status: string
}
