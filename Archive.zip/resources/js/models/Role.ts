export interface Role{
    id: number,
    name:string,
    guard_name: string
}
