@extends('layouts.default')

@section('title')
    Tout nos boutiques
@endsection

@section('content')

{{ $stores }}

@endsection