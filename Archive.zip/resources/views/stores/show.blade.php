@extends('layouts.default')

@section('title')
    {{ $store->name }}
@endsection

@section('content')

@endsection