<div class="flex items-center">
    <div class="bg-primary rounded-sm h-[30px] w-[15px]"></div>
    <h4 class="text-sm font-medium text-primary px-4">{{$title}}</h4>
</div>
