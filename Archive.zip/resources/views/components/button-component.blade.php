<div>
    <button type="button" class="bg-primary dark:bg-primary-dark text-white py-2 px-8 rounded-md">
        <a href="{{$link}}">{{$title}}</a>
    </button>
</div>
