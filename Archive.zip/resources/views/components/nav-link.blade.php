<li class="menu-category">
    <a href="{{ $href }}"
        class="@if($isActive) menu-title-active @endif menu-title">{{ $name }}</a>
</li>
