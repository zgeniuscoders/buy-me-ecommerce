@extends('layouts.auth')

@section('title')
    Reinitialisation mot de passe
@endsection

@section('main')
    
@endsection